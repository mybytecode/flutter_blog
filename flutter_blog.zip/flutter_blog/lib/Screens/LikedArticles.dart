
import 'package:flutter/cupertino.dart';

class LikedArticles extends StatefulWidget
{
  @override
  State<StatefulWidget> createState() => LikedArticleState();

}

class LikedArticleState extends State< LikedArticles >
{
  @override
  Widget build(BuildContext context) {
    return Text("Hello");
  }

}