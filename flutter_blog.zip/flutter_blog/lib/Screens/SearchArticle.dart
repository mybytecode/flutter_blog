/*
 * Copyright 2019 mybytecode
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import 'package:flutter/material.dart';
import 'package:flutter_blog/Future/Categories.dart';
import 'package:flutter_blog/Future/SearchPost.dart';
import 'package:flutter_blog/utils/Utils.dart';
import 'package:flutter_blog/widgets/Loader.dart';

import 'DisplayArticle.dart';

class SearchArticle extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => SearchArticleState();
}

class SearchArticleState extends State<SearchArticle> {
  final textController = TextEditingController();
  String searchTerm;
  bool queryState = false;

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
        child: Scaffold(
      appBar: new AppBar(
        title: TextField(
          controller: textController,
          style: TextStyle(color: Colors.white),
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
              hintStyle: TextStyle(color: Colors.white),
              hintText: "Search News , Author , Articles..."),
          cursorColor: Colors.white,
          onSubmitted: searchNews(),
        ),
      ),
      body: Container(
        child:
            (queryState) ? _newsLoader() : Center(child: Text("Search Term")),
        /*child:FutureBuilder(
                  future: SearchPost(searchTerm).getNews(),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.data == null) {
                      return Container(
                        child: Center(
                          child: LoaderTwo(),
                        ),
                      );
                    } else {
                      return CustomScrollView(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        slivers: <Widget>[_newsList(context, snapshot)],
                      );
                    }
                  })
          */
      ),
    ));
  }

  searchNews() {
    if (textController.text.length > 1) {
      queryState = true;
    }
  }

  Widget _newsLoader() {
    return FutureBuilder(
      future: SearchPost(textController.text).getNews(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        return ListView.builder(
          itemCount: snapshot?.data?.length ?? 0,
          itemBuilder: (BuildContext context, int index) {
            if (snapshot.data.length == null) {
              return Container(
                child: Center(
                  child: LoaderTwo(),
                ),
              );
            } else {
              return ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => DisplayArticle(
                              Utils().parseHTML(
                                  snapshot.data[index].title.rendered),
                              snapshot.data[index].embedded.media[0].sourceLink,
                              snapshot.data[index].categories[0],
                              snapshot.data[index].date,
                              snapshot.data[index].link,
                              Utils().parseHTML(
                                  snapshot.data[index].content.rendered),
                              snapshot.data[index].id)));
                },
                leading: Image.network(
                  snapshot.data[index].embedded.media[0].sourceLink,
                  width: 80,
                  height: 120,
                ),
                title: Text(
                  Utils().parseHTML(snapshot.data[index].title.rendered),
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.black12,
                          borderRadius: BorderRadius.circular(10)),
                      margin: EdgeInsets.only(top: 5, left: 5),
                      padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                      child: Text(
                        Utils().dateParse(snapshot.data[index].date),
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 5, left: 5),
                      padding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                          color: Utils().getRandomColor(),
                          borderRadius: BorderRadius.circular(10)),
                      child: FutureBuilder(
                        future: GetCategoriesById(
                                snapshot.data[index].categories[0])
                            .getCategories(),
                        builder:
                            (BuildContext context, AsyncSnapshot snapshotC) {
                          if (snapshotC.data == null) {
                            return Text("India",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 10));
                          } else {
                            return Text(
                              snapshotC.data,
                              style:
                                  TextStyle(color: Colors.white, fontSize: 10),
                            );
                          }
                        },
                      ),
                    ),
                  ],
                ),
              );
            }
          },
        );
      },
    );
  }
}
